#!/bin/bash

kubectl patch "$1" -p '{"metadata":{"finalizers": []}}' --type=merge